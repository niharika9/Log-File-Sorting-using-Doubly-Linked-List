#ifndef _WARMUP1_H_
#define _WARMUP1_H_
typedef struct inputdata
{
  char *transaction_type;
  long int timestamp_val;
  char *description;
 int amount;
}MyData;
#endif /*_MYHEADER_H_*/
